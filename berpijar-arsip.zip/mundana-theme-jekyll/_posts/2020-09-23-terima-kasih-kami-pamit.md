---
layout: post
title:  "Terima kasih, kami pamit!"
categories: [ Redaksi ]
image: assets/images/home.jpg
tags: [sticky,featured]
---

Terima kasih atas perjalanan yang berkesan, artikel yang mencerahkan, dan resensi yang tajam dari para penulis dan pembaca Berpijar! Setelah 2 tahun dan 5 bulan, Berpijar kini harus pamit dan tak lagi beroperasi. Meskipun demikian, kami menyediakan situs ini bagi arsip tulisan-tulisan yang pernah tayang di Berpijar.

Ini adalah situs pengarsipan. Situs ini hanya menampilkan artikel dan rujukan yang sebelumnya pernah tayang di Berpijar.co (yang kini tak lagi beroperasi). Kami harap, artikel dan resensi tersebut tetap dapat memberi manfaat bagi pembaca.

Bagi pembaca yang baru menemukan situs ini, selamat datang, semoga artikel yang ada di arsip ini masih memberi manfaat bagi pembaca. Perlu diperhatikan, bahwa situs ini **tidak menerima dan menerbitkan artikel atau resensi apapun**. Pertanyaan mengenai situs, silahkan dialamatkan ke [redaksi.berpijar@gmail.com](mailto:redaksi.berpijar@gmail.com). Mengingat bahwa berpijar/arsip tidak secara aktif dikelola, setiap email yang masuk mungkin membutuhkan waktu sedikit lama untuk direspon. Namun, kami akan tetap merespon sebaik mungkin. Mohon tidak mengirimkan email terkait kemungkinan aktivasi kembali situs Berpijar.

Akhir kata, selamat menjelajah **berpijar/arsip**!

Salam hangat,

berpijar/arsip