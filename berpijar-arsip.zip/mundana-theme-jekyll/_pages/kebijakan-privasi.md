---
title: "Kebijakan Privasi"
layout: "page-sidebar"
permalink: "/kebijakan-privasi.html"
---

Seluruh tulisan di situs **{{site.name}}** ditujukan untuk segala kebutuhan edukasi dan tukar pikiran bagi semua orang. Dengan demikian, redaksi memberikan keleluasan kepada pembaca untuk mengutip (bukan _co-paste_ atau plagiat) tulisan-tulisan yang ada di {{site.name}} dengan syarat tetap mencantumkan sumbernya. Jika suatu saat redaksi menemukan adanya “pencurian” konten atau materi dari situs {{site.name}} yang tidak sesuai dengan kaidah jurnalistik, Redaksi akan melakukan tindakan sesuai dengan kode etik jurnalistik dan peraturan hukum yang berlaku.

Redaksi {{site.name}} tetap melindungi setiap hak cipta atau hak pribadi yang muncul di situs Berpijar.co atas setiap informasi yang ada, seperti gambar atau foto, dokumen, data, dan lain-lain.

Untuk lebih mengenal tentang situs ini, terutama terkait alasan dan tujuan pembuatan situs ini, silahkan kunjungi bagian "[Tentang Situs](/tentang-situs.html)".
