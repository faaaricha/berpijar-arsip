---
title: "Tentang Situs"
layout: "page-sidebar"
permalink: "/tentang-situs.html"
---

## {{site.name}}

Ini adalah arsip situs **Berpijar.co**, kami menamainya **{{site.name}}**. Berpijar.co adalah website opini dan rujukan yang aktif selama Mei 2018-September 2020. Selama lebih dari 2 tahun, Berpijar.co telah menyajikan berbagai opini dan rujukan yang mengangkat topik sosial-politik, ekonomi, dan kajian keislaman. Pembaca Berpijar.co utamanya berasal dari mahasiswa ilmu sosial dan ilmu politik. Berawal dari sebuah diskusi dan pengembangan terus-terus di Surabaya, kami yang di Berpijar.co kini memutuskan untuk menghentikan aktivitas Berpijar.co dan mengarsipkan situs.

Artikel-artikel yang telah tayang di Berpijar.co kini tetap tersimpan di {{site.name}}. Situs {{site.name}} **TIDAK MENERIMA DAN MENERBITKAN ARTIKEL / RESENSI**. Ini adalah situs pengarsipan. Situs ini hanya menampilkan artikel dan rujukan yang sebelumnya pernah tayang di Berpijar.co (yang kini tak lagi beroperasi). Kami harap, artikel dan resensi tersebut tetap dapat memberi manfaat bagi pembaca.

Artikel dan resensi yang ada di {{site.name}} sepenuhnya milik penulis. Kami tidak memegang hak cipta maupun hak komersil atas setiap artikel dan resensi dalam situs ini. Pertanyaan lebih lanjut mengenai situs, dan apabila pembaca adalah salah satu penulis yang karyanya pernah dimuat di Berpijar.co, dapat menghubungi kami di [redaksi.berpijar@gmail.com](mailto:redaksi.berpijar@gmail.com).

Terima kasih.

---

#### Alasan Membuat Berpijar.co

Berbeda dengan bentuk media-media konvensional sebelumnya, baik TV, radio maupun koran, media komunikasi berbasis jejaring internet memiliki sebuah ciri yang berbeda secara signifikan. Ketika kehidupan sosial telah melebur ke dalam ruang publik virtual yang menganga lebar untuk menciptakan interaksi sosial dengan dunianya tersendiri, arus informasi tidak hanya berlangsung satu arah, melainkan dua arah bahkan dari berbagai arah.

Setiap orang bukan hanya berperan secara pasif sebagai konsumen terhadap suatu wacana yang datang, namun dapat menjadi produsen sekaligus. Teknologi komunikasi melalui media sosial maupun portal yang menyediakan beragam informasi menjadi semacam “podium” bagi setiap orang untuk bisa berkhotbah tentang berbagai persoalan.

Sayangnya, ada semacam paradoks yang berlangsung di era kebebasan berpendapat tanpa batas tersebut: ketika kemudahan untuk mengakses informasi begitu meluas, namun pikiran net generation cenderung menyempit. Setiap wacana yang memenuhi jagat media sosial bagi kalangan pemuda urban kebanyakan serba sepenggal-sepenggal dan terbata-bata.

Pertukaran pesan singkat yang tergesa-gesa hanya akan menjadikan kesadaran yang bersifat sesaat dan bisa-bisa sesat. Sebuah indikasi kuat bagi masyarakat Indonesia yang berkiblat pada budaya lisan berkepanjangan (Heryanto, 2008: 163). Fenomena ini bisa dibaca sebagai sebuah psikologi sosial masyarakat Indonesia yang ingin serba instan dalam memperoleh sebuah wacana, dan buru-buru untuk disebarkan secara berantai ke setiap orang.

Masyarakat Indonesia hanya perlu meluangkan sedikit waktunya bagi artikel-artikel pendek yang bertebaran di internet untuk dijadikan sebagai rujukan dalam melihat masalah atau berasumsi terhadap masalah tertentu.

Tentu, apa yang terjadi di atas, harus diakui ditopang oleh berbagai website yang menfasilitasi dorongan bagi pengguna internet dengan konten-konten pendek yang ringkas. Ini bisa dibaca juga sebagai upaya apik pengelola media atas pembacaan ceruk psiologis-sosial masyarakat Indonesia kebanyakan.

Berangkat dari berbagai uraian yang telah kami kemukakan, menjadi penting bagi sekelompok pemuda terpelajar untuk mengambil peran bukan hanya menjadi konsumen informasi atau wacana semata, namun juga memproduksi wacana sebagai bukti ikut merayakan kebebasan berkomunikasi sekarang.

Berikutnya yang tidak kalah penting, adalah sebuah kebutuhan akan hadirnya portal media online yang berusaha menjadi alternatif wacana untuk melayani pengguna internet. Sebagai pembeda, wacana alternatif yang ditawarkan haruslah memiliki telaah yang berbeda, tidak sekedar beropini, namun harus memiliki landasan atau rujukan ilmiah yang harus diperhatikan untuk membaca sebuah fenomena yang terjadi, baik sosial, politik dan kebudayaan.

Semacam sebuah usaha untuk mengintegrasikan budaya literasi, yang cukup bertolak dari kebudayaan lisan di Indonesia, dengan apa yang sedang terjadi. Meskipun harus ada sedikit reduksi seperlunya untuk memenuhi tuntutan dalam pergaulan umum warga net. Ini adalah sebagian alasan kami membangun website Berpijar.co.