---
title: "Disclaimer"
layout: "page-sidebar"
permalink: "/disclaimer.html"
---

Setiap konten atau materi yang merupakan karya tulis atas nama “Redaksi” sepenuhnya merupakan tanggung jawab dari Redaksi {{site.name}}. Sedangkan setiap konten atau materi yang ditulis oleh pengunjung atau pembaca yang dikirimkan kepada redaksi melalui email sepenuhnya merupakan tanggung jawab pihak penulis.

Redaksi berhak untuk menolak atau mempublikasikan serta mengedit tulisan tanpa mengubah isi dari konten atau materi tersebut. Jika ada keluhan terkait konten tulisan yang bukan dari redaksi akan diteruskan kepada pihak pengirim. Redaksi berhak menghapus tulisan yang sudah terunggah jika terbukti tulisan tersebut mengandung plagiarism atau bermasalah secara hukum. Silahkan melaporkan jika ada konten atau materi yang diduga mengandung unsur plagiarism atau bermasalah secara hukum melalui "[Kontak](/kontak.html)" yang tersedia.

Dalam banyak tulisan, sebagai penguatan data dan argumen, Redaksi {{site.name}} juga menanam link untuk menuju website atau situs lain. Redaksi berusaha bahwa situs eksternal yang Redaksi {{site.name}} rujuk adalah hyperlink yang kredibel. Namun Redaksi tidak bisa memiliki kontrol yang kuat untuk menilai isi dan sifat situs tersebut. Sehingga, silahkan pelajari kebijakan privasi dari situs tersebut.

Redaksi tidak bertanggung jawab ketika ada pihak lain memanfaatkan konten atau materi di situs {{site.name}} untuk kepentingan komersial dan politis.

**Hormat Kami,**

{{site.name}}